﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FundamentalsWeek2
{
    internal static class Printing
    {
        internal static void Print(string content)
        {
            Console.WriteLine(content);
        }

        internal static void Print()
        {
            Console.WriteLine("");
        }
    }
}
