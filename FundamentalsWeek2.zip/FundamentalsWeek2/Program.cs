﻿using System;
using System.Collections.Generic;
using System.Linq;
using static FundamentalsWeek2.DataSorting;

namespace FundamentalsWeek2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            SortData();
        }
    }

    

    

    
}
